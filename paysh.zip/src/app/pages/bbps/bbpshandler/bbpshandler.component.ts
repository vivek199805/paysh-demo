import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bbpshandler',
  templateUrl: './bbpshandler.component.html',
  styleUrls: ['./bbpshandler.component.css']
})
export class BbpshandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
