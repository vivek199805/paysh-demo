import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashdeposit-handler',
  templateUrl: './cashdeposit-handler.component.html',
  styleUrls: ['./cashdeposit-handler.component.css']
})
export class CashdepositHandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
