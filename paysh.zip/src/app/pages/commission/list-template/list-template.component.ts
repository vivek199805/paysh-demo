import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-template',
  templateUrl: './list-template.component.html',
  styleUrls: ['./list-template.component.css']
})
export class ListTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
