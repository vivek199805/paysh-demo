import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-othercomm',
  templateUrl: './othercomm.component.html',
  styleUrls: ['./othercomm.component.css']
})
export class OthercommComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
