import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-create-handler',
  templateUrl: './account-create-handler.component.html',
  styleUrls: ['./account-create-handler.component.css']
})
export class AccountCreateHandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
