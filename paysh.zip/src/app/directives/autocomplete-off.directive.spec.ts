import { AutocompleteOffDirective } from './autocomplete-off.directive';

describe('AutocompleteOffDirective', () => {
  it('should create an instance', () => {
    const directive = new AutocompleteOffDirective();
    expect(directive).toBeTruthy();
  });
});
