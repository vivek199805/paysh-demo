import { OtpVerificationDirective } from './otp-verification.directive';

describe('OtpVerificationDirective', () => {
  it('should create an instance', () => {
    const directive = new OtpVerificationDirective();
    expect(directive).toBeTruthy();
  });
});
