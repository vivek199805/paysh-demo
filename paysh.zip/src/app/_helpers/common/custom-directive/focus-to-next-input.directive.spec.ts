import { FocusToNextInputDirective } from './focus-to-next-input.directive';

describe('FocusToNextInputDirective', () => {
  it('should create an instance', () => {
    const directive = new FocusToNextInputDirective();
    expect(directive).toBeTruthy();
  });
});
