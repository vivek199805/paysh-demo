import { GetTypeOfPipe } from './get-type-of.pipe';

describe('GetTypeOfPipe', () => {
  it('create an instance', () => {
    const pipe = new GetTypeOfPipe();
    expect(pipe).toBeTruthy();
  });
});
