import { GetIndexPipe } from './get-index.pipe';

describe('GetIndexPipe', () => {
  it('create an instance', () => {
    const pipe = new GetIndexPipe();
    expect(pipe).toBeTruthy();
  });
});
