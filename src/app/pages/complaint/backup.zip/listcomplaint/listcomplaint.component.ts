import { Component, OnInit } from '@angular/core';
import { config } from 'src/app/service/config'; 


@Component({
  selector: 'app-listcomplaint',
  templateUrl: './listcomplaint.component.html',
  styleUrls: ['./listcomplaint.component.css']
})
export class ListcomplaintComponent implements OnInit {

  url: string = config.complaint.list; 
  
  columns: any = [ 
    {
      title: 'Ticket No',
      data: 'ticket_no'
    },
    {
      title: 'Sender Name',
      data: 'sender_name'
    },
    {
      title:'Type',
      data:'type'
    },
    {
      title:'Transaction Id',
      data:'transaction_id'
    },
    {
      title:'Status',
      data:'status'
    },
    {
      title: "Action",
      data: 'id',
      pipe: function (obj:any) {
        return "<a routerLink='/complaint/complaint-chat/"+obj.ticket_no+"' class='btn btn-primary'>View</a>";
      }
    }
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
