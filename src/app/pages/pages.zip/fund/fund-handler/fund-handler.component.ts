import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fund-handler',
  templateUrl: './fund-handler.component.html',
  styleUrls: ['./fund-handler.component.css']
})
export class FundHandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
