import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';
import { config } from 'src/app/service/config';
import { UserLoginDtlService } from 'src/app/service/user-login-dtl.service';
import { DataTableToolsComponent } from 'src/app/_helpers/data-table-tools/data-table-tools.component';
import Swal from 'sweetalert2';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-statment-debit-ledger',
  templateUrl: './statment-debit-ledger.component.html',
  styleUrls: ['./statment-debit-ledger.component.css']
})
export class StatmentDebitLedgerComponent implements OnInit {

  @ViewChild(DataTableToolsComponent) dt!: DataTableToolsComponent;
  search: any = { startdate: "", enddate: "" };
  maxDate!: Date;
  url: string = config.statement.debitLedger;

  columns: any = [];
  userType: any;

  exceldownurl: string = config.downloadstatement.aeps;
  downloadexl: any;
  constructor(private _UserLoginDtlService: UserLoginDtlService, private api: ApiService) {

  }

  ngOnInit(): void {
    const date = new Date();
    this.maxDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

    this._UserLoginDtlService.geterUserLoginDtl.subscribe((val: any) => {

      if (val) {
        this.userType = val.usertype;
      }
    })
    this.setTblHeader();
  }

  setTblHeader() {
    let heading: any;

    switch (+this.userType) {
      case 0:

        heading = [
          {
            data: "txnid",
            "table_column": "tc.txnid",
            title: "Transaction id",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "sopening",
            "table_column": "tc.sopening",
            title: "Opening Balance",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "amount",
            "table_column": "tc.amount",
            title: "Amount",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "comm",
            "table_column": "tc.comm",
            title: "Retailer Commission",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "dcomm",
            "table_column": "tc.dcomm",
            title: "Distributor Commission",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "pcomm",
            "table_column": "tc.pcomm",
            title: "Partner Commission",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "sdcomm",
            "table_column": "tc.sdcomm",
            title: "Super Distributor Commission",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "gst",
            "table_column": "tc.gst",
            title: "GST",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "tds",
            "table_column": "tc.tds",
            title: "TDS",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "sclosing",
            "table_column": "tc.sclosing",
            title: "Closing Balance",
            "is_show": 1,
            "issort": 1,
            pipe: "currrency"
          },
          {
            data: "stype",
            "table_column": "tc.stype",
            title: "Type",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "narration",
            "table_column": "tc.narration",
            title: "Narration",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "remarks",
            "table_column": "tc.remarks",
            title: "Remarks",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "ttype",
            "table_column": "tc.ttype",
            title: "Transaction Type",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "dateadded",
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          }
        ]
        break;

      case 1:
        heading = [
          {
            data: 'txnid',
            "table_column": 'tc.txnid',
            title: 'txnid',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'aopening',
            "table_column": 'tc.aopening',
            title: 'aopening',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'amount',
            "table_column": 'tc.amount',
            title: 'amount',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'comm',
            "table_column": 'tc.comm',
            title: 'comm',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dcomm',
            "table_column": 'tc.dcomm',
            title: 'dcomm',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'pcomm',
            "table_column": 'tc.pcomm',
            title: 'pcomm',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'sdcomm',
            "table_column": 'tc.sdcomm',
            title: 'sdcomm',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'gst',
            "table_column": 'tc.gst',
            title: 'gst',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'tds',
            "table_column": 'tc.tds',
            title: 'tds',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'aclosing',
            "table_column": 'tc.aclosing',
            title: 'aclosing',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'atype',
            "table_column": 'tc.atype',
            title: 'atype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'narration',
            "table_column": 'tc.narration',
            title: 'narration',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'remarks',
            "table_column": 'tc.remarks',
            title: 'remarks',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'ttype',
            "table_column": 'tc.ttype',
            title: 'ttype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          }

        ];
        break;

      case 2:
        heading = [
          {
            data: 'txnid',
            "table_column": 'txnid',
            title: 'txnid',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'sdopening',
            "table_column": 'tc.sdopening',
            title: 'sdopening',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'mount',
            "table_column": 'tc.mount',
            title: 'mount',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'comm',
            "table_column": 'tc.comm',
            title: 'comm',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'gst',
            "table_column": 'tc.gst',
            title: 'gst',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'tds',
            "table_column": 'tc.tds',
            title: 'tds',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'closing',
            "table_column": 'tc.closing',
            title: 'closing',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'sdtype',
            "table_column": 'tc.sdtype',
            title: 'sdtype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'narration',
            "table_column": 'tc.narration',
            title: 'narration',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'remarks',
            "table_column": 'tc.remarks',
            title: 'remarks',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'ttype',
            "table_column": 'tc.ttype',
            title: 'ttype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          }
        ];
        break;

      case 3:
        heading = [
          {
            data: 'txnid',
            "table_column": 'tc.txnid',
            title: 'txnid',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'popening',
            "table_column": 'tc.popening',
            title: 'popening',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'amount',
            "table_column": 'tc.amount',
            title: 'amount',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'comm',
            "table_column": 'tc.comm',
            title: 'comm',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'gst',
            "table_column": 'tc.gst',
            title: 'gst',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'tds',
            "table_column": 'tc.tds',
            title: 'tds',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'pclosing',
            "table_column": 'tc.pclosing',
            title: 'pclosing',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'ptype',
            "table_column": 'tc.ptype',
            title: 'ptype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'narration',
            "table_column": 'tc.narration',
            title: 'narration',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'remarks',
            "table_column": 'tc.remarks',
            title: 'remarks',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'ttype',
            "table_column": 'tc.ttype',
            title: 'ttype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          }
        ];
        break;

      case 4:
        heading = [
          {
            data: 'txnid',
            "table_column": 'tc.txnid',
            title: 'txnid',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dopening',
            "table_column": 'tc.dopening',
            title: 'dopening',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'amount',
            "table_column": 'tc.amount',
            title: 'amount',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'comm',
            "table_column": 'tc.comm',
            title: 'comm',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'gst',
            "table_column": 'tc.gst',
            title: 'gst',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'tds',
            "table_column": 'tc.tds',
            title: 'tds',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dclosing',
            "table_column": 'tc.dclosing',
            title: 'dclosing',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dtype',
            "table_column": 'tc.dtype',
            title: 'dtype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'narration',
            "table_column": 'tc.narration',
            title: 'narration',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'remarks',
            "table_column": 'tc.remarks',
            title: 'remarks',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'ttype',
            "table_column": 'tc.ttype',
            title: 'ttype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          }
        ];
        break;

      case 5:
        heading = [
          {
            data: 'txnid',
            "table_column": 'tc.txnid',
            title: 'txnid',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'cd_opening',
            "table_column": 'tc.cd_opening',
            title: 'cd_opening',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'amount',
            "table_column": 'tc.amount',
            title: 'amount',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'comm',
            "table_column": 'tc.comm',
            title: 'comm',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'gst',
            "table_column": 'tc.gst',
            title: 'gst',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'tds',
            "table_column": 'tc.tds',
            title: 'tds',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'cd_closing',
            "table_column": 'tc.cd_closing',
            title: 'cd_closing',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'utype',
            "table_column": 'tc.utype',
            title: 'utype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'narration',
            "table_column": 'tc.narration',
            title: 'narration',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'ttype',
            "table_column": 'tc.ttype',
            title: 'ttype',
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          }
        ];
        break;

      default:
        break;
    }
    this.columns = heading;

  }

  filter() {
    let search: any = {};
    search.startdate = this.dt.transform(this.search.startdate);
    search.enddate = this.dt.transform(this.search.enddate);
    this.dt.filter(search)
  }
  download($event: any) {
    let startdate = this.dt.transform(this.search.startdate);
    let enddate = this.dt.transform(this.search.enddate);
    let formdata: any = new FormData();
    formdata.append('token', config.tokenauth);
    formdata.append('startdate', (startdate === null ? '' : startdate));
    formdata.append('enddate', (startdate === null ? '' : enddate));
    this.api.postdata(formdata, config.downloadstatement.aeps).subscribe((res: any) => {
      if (res.statuscode == 200) {
        const fileName = 'Aeps-Statement.xlsx';
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(res['data']);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Aeps-Statement');
        XLSX.writeFile(wb, fileName);
      } else {
        Swal.fire({
          icon: 'error',
          title: res.message
        })
      }
    });
  }

  GetChildData(data: any) {
    this.downloadexl = data;
    console.log(data);

  }
}
