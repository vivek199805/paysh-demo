import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';
import { config } from 'src/app/service/config';
import { UserLoginDtlService } from 'src/app/service/user-login-dtl.service';
import { DataTableToolsComponent } from 'src/app/_helpers/data-table-tools/data-table-tools.component';
import Swal from 'sweetalert2';
import * as XLSX from 'xlsx';
@Component({
  selector: 'app-statment-credit-ledger',
  templateUrl: './statment-credit-ledger.component.html',
  styleUrls: ['./statment-credit-ledger.component.css']
})
export class StatmentCreditLedgerComponent implements OnInit {

  @ViewChild(DataTableToolsComponent) dt!: DataTableToolsComponent;
  search: any = { startdate: "", enddate: "" };
  maxDate!: Date;
  url: string = config.statement.creditLedger;

  columns: any = [];
  userType: any;

  exceldownurl: string = config.downloadstatement.aeps;
  downloadexl: any;

  constructor(private _UserLoginDtlService: UserLoginDtlService, private api: ApiService) {

  }

  ngOnInit(): void {
    const date = new Date();
    this.maxDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

    this._UserLoginDtlService.geterUserLoginDtl.subscribe((val: any) => {

      if (val) {
        this.userType = val.usertype;
      }
    })
    this.setTblHeader();
  }

  setTblHeader() {
    let heading: any;
    switch (+this.userType) {
      case 0:

        heading = [
          {
            data: "txnid",
            "table_column": "tc.txnid",
            title: "Transaction id",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "txnid",
            "table_column": 't.txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "amount",
            "table_column": 't.amount',
            title: "amount",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "comm",
            "table_column": 't.comm',
            title: "comm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "dcomm",
            "table_column": 't.dcomm',
            title: "dcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "pcomm",
            "table_column": 't.pcomm',
            title: "pcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "sdcomm",
            "table_column": 't.sdcomm',
            title: "sdcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "gst",
            "table_column": 't.gst',
            title: "gst",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "tds",
            "table_column": 't.tds',
            title: "tds",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "stype",
            "table_column": 't.stype',
            title: "stype",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "narration",
            "table_column": 't.narration',
            title: "narration",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "remarks",
            "table_column": 't.remarks',
            title: "remarks",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "ttype",
            "table_column": 't.ttype',
            title: "ttype",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "dateadded",
            "table_column": 't.dateadded',
            title: "dateadded",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "dateadded",
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          }
        ]
        break;

      case 1:
        heading = [
          {
            data: "txnid",
            "table_column": 't.txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "amount",
            "table_column": 't.amount',
            title: "amount",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "comm",
            "table_column": 't.comm',
            title: "comm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "dcomm",
            "table_column": 't.dcomm',
            title: "dcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "pcomm",
            "table_column": 't.pcomm',
            title: "pcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "sdcomm",
            "table_column": 't.sdcomm',
            title: "sdcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "gst",
            "table_column": 't.gst',
            title: "gst",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "tds",
            "table_column": 't.tds',
            title: "tds",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "narration",
            "table_column": 't.narration',
            title: "narration",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "remarks",
            "table_column": 't.remarks',
            title: "remarks",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "ttype",
            "table_column": 't.ttype',
            title: "ttype",
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          },
        ]
        break;

      case 2:
        heading = [
          {
            data: "txnid",
            "table_column": 't.txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },

          {
            data: "amount",
            "table_column": 't.amount',
            title: "amount",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "sdcomm",
            "table_column": 't.sdcomm',
            title: "sdcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "gst",
            "table_column": 't.gst',
            title: "gst",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "tds",
            "table_column": 't.tds',
            title: "tds",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "narration",
            "table_column": 't.narration',
            title: "narration",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "remarks",
            "table_column": 't.remarks',
            title: "remarks",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "ttype",
            "table_column": 't.ttype',
            title: "ttype",
            "is_show": 1,
            "issort": 1
          },
          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          },
        ]
        break;

      case 3:
        heading = [
          {
            data: "txnid",
            "table_column": 't.txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "txnid",
            "table_column": 'txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "amount",
            "table_column": 't.amount',
            title: "amount",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "pcomm",
            "table_column": 't.pcomm',
            title: "pcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "gst",
            "table_column": 't.gst',
            title: "gst",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "tds",
            "table_column": 't.tds',
            title: "tds",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "narration",
            "table_column": 't.narration',
            title: "narration",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "remarks",
            "table_column": 't.remarks',
            title: "remarks",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "ttype",
            "table_column": 't.ttype',
            title: "ttype",
            "is_show": 1,
            "issort": 1
          },

          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          },
        ]
        break;

      case 4:
        heading = [
          {
            data: "txnid",
            "table_column": 't.txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "txnid",
            "table_column": 'txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "amount",
            "table_column": 't.amount',
            title: "amount",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "dcomm",
            "table_column": 't.dcomm',
            title: "dcomm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "gst",
            "table_column": 't.gst',
            title: "gst",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "tds",
            "table_column": 't.tds',
            title: "tds",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "narration",
            "table_column": 't.narration',
            title: "narration",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "remarks",
            "table_column": 't.remarks',
            title: "remarks",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "ttype",
            "table_column": 't.ttype',
            title: "ttype",
            "is_show": 1,
            "issort": 1
          },

          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          },
        ]
        break;

      case 5:
        heading = [
          {
            data: "txnid",
            "table_column": 't.txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "txnid",
            "table_column": 'txnid',
            title: "txnid",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "amount",
            "table_column": 't.amount',
            title: "amount",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "comm",
            "table_column": 't.comm',
            title: "comm",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "gst",
            "table_column": 't.gst',
            title: "gst",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "tds",
            "table_column": 't.tds',
            title: "tds",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "utype",
            "table_column": 't.utype',
            title: "utype",
            "is_show": 1,
            "issort": 1
          },
          {
            data: "narration",
            "table_column": 't.narration',
            title: "narration",
            "is_show": 1,
            "issort": 1
          },

          {
            data: "ttype",
            "table_column": 't.ttype',
            title: "ttype",
            "is_show": 1,
            "issort": 1
          },

          {
            data: 'dateadded',
            "table_column": "tc.dateadded",
            title: "Transaction Date",
            "is_show": 1,
            "issort": 1,
            pipe: "date"
          },
        ]
        break;

      default:
        break;
    }

    this.columns = heading;

  }

  filter() {
    let search: any = {};
    search.startdate = this.dt.transform(this.search.startdate);
    search.enddate = this.dt.transform(this.search.enddate);
    this.dt.filter(search)
  }
  download($event: any) {
    let startdate = this.dt.transform(this.search.startdate);
    let enddate = this.dt.transform(this.search.enddate);
    let formdata: any = new FormData();
    formdata.append('token', config.tokenauth);
    formdata.append('startdate', (startdate === null ? '' : startdate));
    formdata.append('enddate', (startdate === null ? '' : enddate));
    this.api.postdata(formdata, config.downloadstatement.aeps).subscribe((res: any) => {
      if (res.statuscode == 200) {
        const fileName = 'Aeps-Statement.xlsx';
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(res['data']);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Aeps-Statement');
        XLSX.writeFile(wb, fileName);
      } else {
        Swal.fire({
          icon: 'error',
          title: res.message
        })
      }
    });
  }

  GetChildData(data: any) {
    this.downloadexl = data;
    console.log(data);

  }
}
