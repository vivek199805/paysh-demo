import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AnyRecord } from 'dns';
import { ApiService } from 'src/app/service/api.service';
import { config } from 'src/app/service/config';
import { CustConfg } from 'src/app/_helpers/common/custom-datepicker/ngx-datePicker-CustConfg';
import { DataTableToolsComponent } from 'src/app/_helpers/data-table-tools/data-table-tools.component';
import Swal from 'sweetalert2';
import * as XLSX from 'xlsx';
declare var $: any;
@Component({
  selector: 'app-statement-dmt',
  templateUrl: './statement-dmt.component.html',
  styleUrls: ['./statement-dmt.component.css']
})
export class StatementDmtComponent implements OnInit {
  @ViewChild(DataTableToolsComponent) dt!: DataTableToolsComponent;
  @ViewChild('modal', { read: ElementRef }) modal!: ElementRef;
  search: any = { startdate: "", enddate: "" };
  maxDate!: Date;
  refundid: any;
  url: string = config.statement.dmt;
  exceldownurl: string = config.downloadstatement.dmt;
  form: any = FormGroup;
  @ViewChild('rangePicker') rangePicker: any;
  downloadexl: any;
  refund: any = FormGroup;
  columns: any = [
    {
      title: 'TXN ID',
      data: 'txnid'
    },
    {
      title: 'Bank name',
      data: 'bankname'
    },
    {
      title: "A/C no",
      data: 'acno'
    },
    {
      title: "Remarks",
      data: 'remarks'
    },
    {
      title: "utr",
      data: 'utr'
    },
    {
      title: "IFSC Code",
      data: 'ifsccode'
    },
    {
      title: "Bene Name",
      data: 'benename'
    },
    {
      title: "Bene Mobile",
      data: 'mobile'
    },
    {
      title: "Amount",
      data: 'amount',
      pipe: "currency"
    },
    {
      title: "Charges",
      data: 'charges',
      pipe: "currency"
    },
    {
      title: "Status",
      data: 'status'
    },
    {
      title: "Date",
      data: 'dateadded',
      pipe: "date"
    },
    {
      title: "Action",
      data: 'id',
      pipe: function (obj: any) {
        let btnStr: any = '';
        let is_query = "<a   routerLink='/statement/query/" + obj.id + "' target='_blank'  class='btn btn-warning btn-sm ml-2 mb-1'>Query</a>";
        let is_process = "<a  routerLink='/statement/process/" + obj.id + "'  target='_blank' class='btn btn-success btn-sm ml-2  mb-1'>Process</a>";
        let is_refund = "<a (click)='showRefundModel' #modal data-toggle='modal' data-target='#transactionStatus'  class='btn btn-primary btn-sm ml-2  mb-1'>Refund</a>";

        if (obj.is_query == 1) {
          btnStr += is_query;
        }
        if (obj.is_process == 1) {
          btnStr += is_process;
        }
        if (obj.is_refund == 1) {
          btnStr += is_refund;
        }
        // console.log(btnStr);

        return (obj.is_query == 0 && obj.is_process == 0 && obj.is_refund == 0) ? 'No Action Found' : btnStr;
      }
    },
    {
      title: "Print",
      pipe: 'print'
    }
  ];
  bsCustConfg = CustConfg;
  minDate!: Date;
  constructor(private api: ApiService) {
    this.form = new FormGroup({
      selectdate: new FormControl([new Date(), new Date()], [Validators.required]),
    })
    this.refund = new FormGroup({
      authcode: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]\d*$/)]),
    });
  }

  ngOnInit(): void {
    const date = new Date();
    this.minDate = new Date(1950, 1, 1);
    this.maxDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  }

  funObj(obj: any) {
    var key = obj.key;
    var value = obj.value;
    this.refundid = obj.value.id;
    // console.log(value);

  }
  filter() {
    let search: any = {};
    search.startdate = this.dt.transform(this.form.get('selectdate')?.value[0]);
    search.enddate = this.dt.transform(this.form.get('selectdate')?.value[1]);
    this.dt.filter(search)
  }

  onDateRangePickerShow() {
    // This is a workaround to show previous month
    var prevMonth = new Date();
    prevMonth.setMonth(prevMonth.getMonth() - 1);
    this.rangePicker._datepicker.instance.monthSelectHandler({ date: prevMonth });
  }

  download($event: any) {
    let startdate = this.dt.transform(this.form.get('selectdate')?.value[0]);
    let enddate = this.dt.transform(this.form.get('selectdate')?.value[1]);
    let formdata: any = new FormData();
    formdata.append('token', config.tokenauth);
    formdata.append('startdate', (startdate === null ? '' : startdate));
    formdata.append('enddate', (startdate === null ? '' : enddate));
    this.api.postdata(formdata, this.exceldownurl).subscribe((res: any) => {
      if (res.statuscode == 200) {
        const fileName = 'Dmt-Statement.xlsx';
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(res['data']);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Dmt-Statement');
        XLSX.writeFile(wb, fileName);
      } else {
        Swal.fire({
          icon: 'error',
          title: res.message
        })
      }
    });
  }

  GetChildData(data: any) {
    this.downloadexl = data;
  }
  closeModal() {
    console.log('');
    $("#transactionStatus").modal('hide');
  }
  request_refund() {
    let formdata: any = new FormData();
    formdata.append('token', config.tokenauth);
    formdata.append('id', this.refundid);
    formdata.append('authcode', this.refund.get('authcode')?.value);
    this.api.postdata(formdata, config.statement.refund).subscribe((res: any) => {
      if (res.statuscode == 200) {
        this.closeModal();
        Swal.fire({
          title: res.message,
          icon: 'success'
        });
        this.refund.reset();
      } else {
        this.refund.reset();
        Swal.fire({
          icon: 'error',
          title: res.message
        })
      }
    })
  }
  get r() {
    return this.refund.controls
  }
}