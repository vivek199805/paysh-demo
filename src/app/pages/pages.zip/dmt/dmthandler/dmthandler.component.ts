import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dmthandler',
  templateUrl: './dmthandler.component.html',
  styleUrls: ['./dmthandler.component.css']
})
export class DmthandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
