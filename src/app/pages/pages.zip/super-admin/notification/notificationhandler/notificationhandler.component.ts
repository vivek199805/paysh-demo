import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notificationhandler',
  templateUrl: './notificationhandler.component.html',
  styleUrls: ['./notificationhandler.component.css']
})
export class NotificationhandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
