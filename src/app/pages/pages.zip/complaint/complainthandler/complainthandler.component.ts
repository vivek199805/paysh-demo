import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complainthandler',
  templateUrl: './complainthandler.component.html',
  styleUrls: ['./complainthandler.component.css']
})
export class ComplainthandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
