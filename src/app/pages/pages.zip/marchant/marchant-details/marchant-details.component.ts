import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marchant-details',
  templateUrl: './marchant-details.component.html',
  styleUrls: ['./marchant-details.component.css']
})
export class MarchantDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
