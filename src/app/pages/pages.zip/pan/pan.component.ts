import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pan',
  templateUrl: './pan.component.html',
  styleUrls: ['./pan.component.css']
})
export class PanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
