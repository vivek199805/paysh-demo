import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-card-handler',
  templateUrl: './credit-card-handler.component.html',
  styleUrls: ['./credit-card-handler.component.css']
})
export class CreditCardHandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
