import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scanner-setting',
  templateUrl: './scanner-setting.component.html',
  styleUrls: ['./scanner-setting.component.css']
})
export class ScannerSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
