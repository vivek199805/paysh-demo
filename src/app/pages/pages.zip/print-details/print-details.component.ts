import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-details',
  templateUrl: './print-details.component.html',
  styleUrls: ['./print-details.component.css']
})
export class PrintDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
