import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-template',
  templateUrl: './edit-template.component.html',
  styleUrls: ['./edit-template.component.css']
})
export class EditTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
