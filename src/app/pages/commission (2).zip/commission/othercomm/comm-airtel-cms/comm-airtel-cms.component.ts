import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comm-airtel-cms',
  templateUrl: './comm-airtel-cms.component.html',
  styleUrls: ['./comm-airtel-cms.component.css']
})
export class CommAirtelCmsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
