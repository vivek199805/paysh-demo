import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { config } from 'src/app/service/config';
import { DataTableToolsComponent } from 'src/app/_helpers/data-table-tools/data-table-tools.component';

@Component({
  selector: 'app-list-complaint',
  templateUrl: './list-complaint.component.html',
  styleUrls: ['./list-complaint.component.css'] 
})
export class ListComplaintComponent implements OnInit {
  url: string = config.complaint.adminlist; 
  
  columns: any = [ 
    {
      title: 'Ticket No',
      data: 'ticket_no'
    },
    {
      title:'Transaction Id',
      data:'transaction_id'
    },
    {
      title:'Status',
      data:'status'
    },
    {
      title:'Time',
      data:'time'
    },
    {
      title: "Action",
      data: 'file_url',
      pipe: function (obj:any) {
        return "<a href='"+obj.file_url+"' download class='btn btn-primary'>File</a>";
      }
    },
    {
      title: "Action",
      data: 'id',
      pipe: function (obj:any) {
        return "<a routerLink='/complaint/complaint-chat/"+obj.ticket_no+"' class='btn btn-primary'>View</a>";
      }
    }
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
