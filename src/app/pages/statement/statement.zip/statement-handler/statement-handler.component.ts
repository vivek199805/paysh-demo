import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statement-handler',
  templateUrl: './statement-handler.component.html',
  styleUrls: ['./statement-handler.component.css']
})
export class StatementHandlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
